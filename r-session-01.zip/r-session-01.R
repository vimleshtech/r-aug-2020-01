
#assign right to left
a =211
b = 55

c <- 5555

#assign left to right 
66 -> d

#a,b,c,d are variables

print(a)
print(b)
print(c)
print(d)


# data type
typeof(a)

typeof(b)


a =11 #double
typeof(a)

a ='11' #string  /character
typeof(a)

a = TRUE #boolean /logical 
typeof(a)


a= c(111,3,5,6,77) #list
typeof(a)


#get is type 
a =121
is.numeric(a)

a ='121'
is.numeric(a)
is.character(a)


#type conversation 
a =11
b =22
c =a+b
print(c)

a ='11'
b ='22'
a = as.numeric(a) # type conversion 
b = as.numeric(b)
c =a+b
print(c)


#conditional operator
>
>=
<=
==
!= 
  
#condition 
a =11111
b =455
if (a>b){
  
  print('a is gt')
}else{
  print(' b is gt')
  
}

#if elseif 
a =11111
b =455
c =44000
if (a>b && a>c ){
  
  print('a is gt')
}else if(b>a && b>c) {
  print(' b is gt')
  
}else{
  print('c is gt')
}


#### loop : is iterator or repeation of statment 
a= 1 # start from 
while (a<10){ #condition 
  print(a)
  a=a+1
  
}

#print in reverse
i =10
while(i>0){
  print(i)
  i =i-1
}


##for loop 
a =c(111,2,5,6,7,3,3,3)
print(a)

for(x in a){ #here x is new variable and a is list
  print(x)
}


#get sum of all values
s =0
for(x in a){ #here x is new variable and a is list
  s =s+x
}
print(s)


#get count of all even value
#get sum of all values
ec =0
for(x in a){ #here x is new variable and a is list
  if(x%% 2 == 0){
    ec=ec+1
  }
}
print(ec)


#### rbind and cbind
#list : is collection of values or data
a = c(11,33,44,55,77)
b = c(1,30,404,55,7)

a
b

cbind(a,b) #merge by col
rbind(a,b) #merge by row 

#dataframe
x = data.frame(a,b)

#access col
x$a
x$b




Question B18: WAP to input the sales made by a salesman and calculate the commission according to the following conditions:
  Sales						Commission
1-10000					4%
10001-20000					5%
20001-30000					6%
>30000					7%


Question B40: WAP to input 2 numbers and find out the sum of all the even numbers which are not divisible by 5 but divisible by 3 and lies between the given two numbers.


(1)	2, 4, 8, 16, 32, 64, 128, 256


Question D10: WAP to input 20 values in an integer array and count the negative, positive, odd and even values in the array.
Question D11: Given an array named A with following elements:
  3, -5, 1, 3, 7, 0, -15, 3, -7, -8
WAP to shift the negative numbers to the left and positive numbers to the right so that the resultant array look like the
-5, -15, -7, -8, 3, 1, 3, 7,  0, 3





